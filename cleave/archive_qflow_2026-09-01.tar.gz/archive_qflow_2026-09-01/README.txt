qflow run archive - Cleave RV32I (tt_um_cleave), 2026-09-01
Preserved before pivoting to OpenROAD/OpenLane.
  synthesis/tt_um_cleave.v   - yosys sky130_fd_sc_hd mapped netlist (22,636 cells / 3,072 flops)
  synthesis/tt_um_cleave.sdc - timing constraint (clk @ 40 ns)
  layout/tt_um_cleave.def    - graywolf placement (density 0.30); NOT routed
  qflow_vars.sh/project_vars.sh/qflow_exec.sh - qflow setup
  log/*.log                  - synth/place/route logs (route congested ~4,900 unroutable nets)
qflow ROUTING never converged. OpenLane re-runs P&R from RTL; this placement is not reusable,
kept as a record + netlist cross-check.
